from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.views import AuthenticationForm
from django.contrib.auth.models import User
from django.core.exceptions import  ValidationError
class UserAuthenticationForm(AuthenticationForm):
#	class Meta:
#		fields = "__all__"
#		widgets = {'username':forms.TextInput(attrs={'class':'form-control'}),
#		'password':forms.PasswordInput(attrs={'class':'form-control'})}
		
#	username = forms.CharField(label="username",widget=forms.TextInput(attrs={"class":"form-control"}))
#	password= forms.CharField(label="password",widget=forms.PasswordInput(attrs={"class":"form-control"}))

	
	def clean(self):
			username = self.cleaned_data["username"]
			password = self.cleaned_data["password"]
			user = authenticate(username=username, password=password)
			try:
					if user is not None and user.is_superuser == True or user.is_staff == True:
						
						pass
					
					elif user.is_staff == False or user.is_superuser == False:
							  ValidationError({"username":"this account don't have accessed to login as admin or staff, try using your admin or staff login account!"})
					else:
								ValidationError({'password':"username or password is incorrect"})
								
			except:
				ValidationError({'password': "You enter wrong username and password"})
				
		
	