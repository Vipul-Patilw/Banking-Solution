from django.db import models
from .utils import get_scaned_signatured
from PIL import Image
#import numpy as np
from io import BytesIO
from django.core.files.base import ContentFile
from django.contrib.auth.models import User
import uuid
import os
from django.urls import reverse
from datetime import datetime
# Create your models here.
operator_choice = [('','Select Operator'),('AIRTEL PREPAID','AIRTEL PREPAID'),
('RELIANCE JIO PREPAID','RELIANCE JIO PREPAID'),
('VODAFONE/IDEA PREPAID','VODAFONE/IDEA PREPAID')]
class RechargePlan(models.Model):
	recharge_operator = models.CharField(max_length=122,choices=operator_choice)
	recharge_plan = models.TextField()
	recharge_amount = models.IntegerField()
	add_update_date = models.DateTimeField(auto_now=True)
	recharge_validity_days= models.IntegerField()

def get_file_path_match_signatures(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (uuid.uuid4(), ext)
    return os.path.join('Admin_Portal/match_signatures', filename)

def get_file_path_signatures(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (uuid.uuid4(), ext)
    return os.path.join('Admin_Portal/signatures', filename)

gender=[('','Select Gender'),('male','Male'),('female','Female')]

class SuperUserRegistration(models.Model):
	
	profile_pic = models.ImageField(upload_to= "Admin_Portal/profiles",blank=True)

	first_name = models.CharField(max_length=122)
	
	last_name = models.CharField(max_length=122)
	
	mobile_number= models.CharField(max_length=122)
	
	username= models.CharField(max_length=122)
		
	email= models.CharField(max_length=122)
	
	gender = models.CharField(max_length=122,choices=gender)
	
	class Meta:
		db_table= "Bank_Admin_Portal_user_registration"
		
	def __str__(self):
		return self.first_name 
		
class Staff(models.Model):
	
	first_name = models.CharField(max_length=122)
	
	last_name = models.CharField(max_length=122)
	
	username= models.CharField(max_length=122)
		
	email= models.CharField(max_length=122)
	gender = models.CharField(max_length=122,default="")
	profile_pic = models.CharField(max_length=122,default="",null=True)
		
	def __str__(self):
		return self.first_name 
		
class Admin(models.Model):
	
	first_name = models.CharField(max_length=122)
	
	last_name = models.CharField(max_length=122)
	
	username= models.CharField(max_length=122)
		
	email= models.CharField(max_length=122)
	gender = models.CharField(max_length=122,default="")
	profile_pic = models.CharField(max_length=122,default="",null=True)

		
	def __str__(self):
		return self.first_name 

gender=[(None,'Select Gender'),('male','Male'),('female','Female')]
city=[(None,'Select City'),('mumbai','Mumbai'),('pune','Pune'),('delhi','Delhi')]	
bank=[(None,'Select Bank'),('State Bank Of India','State Bank Of India'),('Kotak Mahindra','Kotak Mahindra'),('Bank Of Maharashtra','Bank Of Maharashtra'),('HDFC','HDFC'),('Bank Of Baroda','Bank Of Baroda')]		
class Users_Account(models.Model):
	
	holder_name = models.CharField(max_length=122)
	
	bank_name = models.CharField(max_length=122,choices=bank)
	
	mobile_number= models.CharField(max_length=122)
	
	account_number= models.CharField(max_length=122)
	
	card_number= models.CharField(max_length=122)
	expired_date= models.CharField(max_length=122)
	cvv = models.CharField(max_length=122)
	
	email= models.CharField(max_length=122)
	
	gender = models.CharField(max_length=122,choices=gender)
	
	city = models.CharField(max_length=122,choices=city)

	balance = models.FloatField(default=0.00)

	birthdate = models.DateField()
	
	signature = models.ImageField(upload_to=get_file_path_signatures,verbose_name=(u'Signature_list'))

	profile_pic = models.ImageField(upload_to= "Admin_Portal/users_profiles")
	address = models.TextField()
	slug = models.SlugField(null=False,unique=True)
	
	def __str__(self):
		return self.holder_name
	def get_absolute_url(self):
		return reverse("user_detail",kwargs={'slug':self.slug})

class MatchSignature(models.Model):
	signature_image = models.ImageField(upload_to=get_file_path_match_signatures,verbose_name=(u'Scanning_list'))
	created = models.DateTimeField(auto_now=True)
	updated = models.DateTimeField(auto_now_add=True)
	def __str__(self):
		return str(self.id)
	# def save(self, *args, **kwargs):
	# 	pil_img = Image.open(self.signature_image)
	# 	cv_img = np.array(pil_img)
	# 	img = get_scaned_signatured(cv_img)
	# 	im_pil = Image.fromarray(img)
	# 	buffer = BytesIO()
	# 	im_pil.save(buffer,format="png")
	# 	img_png = buffer.getvalue()
	# 	self.signature_image.save(str(self.signature_image),ContentFile(img_png),save=False)
	# 	super().save(*args,**kwargs)


