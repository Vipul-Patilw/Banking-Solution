a = ["f","ff","fff"]
b = input(":")
for i in a:
    if i == b:
        print("matched") 
        break
else:
        print("not matched")