from Bank_Admin_Portal.models import Users_Account
from django import forms
import datetime
from django.core.exceptions import ValidationError
import re
from requests import request
class UserAccountCreateForm(forms.ModelForm):

	class Meta:
		model = Users_Account
		date = datetime.date.today()
		fields = '__all__'
	#	labels = {
#		'first_name': 'First Name',
#		
#		'last_name':'Last Name',
#		
#		'mobile_number':'Mobile Number',
#		
#		'username':'Username',
#			
#		'email':'Email',
#		
#		'gender':'Gender',
#	
#		'birthdate':'Birthdate'
#	}
		widgets = {
		'bank_name':forms.Select(attrs={'id':'bank_name','class':'form-select'}),
		'gender':forms.Select(attrs={'id':'gender','class':'form-select'}),
			'city':forms.Select(attrs={'id':'city','class':'form-select'}),
				'address':forms.Textarea(attrs={'id':'address','class':'form-control'}),
					'balance':forms.NumberInput(attrs={'id':'balance','class':'form-control'}),
				'holder_name':forms.TextInput(attrs={'id':'holder_name','class':'form-control'}),
				'profile_pic':forms.FileInput(attrs={'id':"profile" , 'onchange':"loadProfile(event)", 'style':"display: none",'class':'form-control'}),
				'mobile_number':forms.TextInput(attrs={'type':'tel','maxlength':10,'id':'phone','onkeyup':'phoneValidation()','class':'form-control'}),
				'account_number':forms.TextInput(attrs={'type':'tel','maxlength':16,'id':'a_num','onkeyup':'account_number_validation()','class':'form-control'}),
				'card_number':forms.TextInput(attrs={'type':'tel','maxlength':16,'id':'c_num','onkeyup':'card_number_validation()','class':'form-control'}),
				'expired_date':forms.TextInput(attrs={'type':'tel','maxlength':5,'id':'e_date','class':'form-control'}),
				'cvv':forms.TextInput(attrs={'type':'tel','maxlength':3,'id':'cvv','class':'form-control'}),
				'email':forms.EmailInput(attrs={'type':'email','class':'form-control'}),
				'birthdate':forms.DateInput(attrs={'type':'date','max':date,'class':'form-select'}),
				'signature':forms.FileInput(attrs={'id':"signature" , 'onchange':"loadSgnature(event)", 'style':"display: none",'class':'form-control'})}
	def clean(self):
		mobile_number= self.cleaned_data['mobile_number']
		email = self.cleaned_data['email']
		account_number = self.cleaned_data['account_number']
		card_number = self.cleaned_data['card_number']	
		if Users_Account.objects.filter(email=email).exclude(pk=self.instance.pk).exists():
									raise ValidationError({'email':"this email address already registered with us try different email address"})
						
									
		if Users_Account.objects.filter(mobile_number=mobile_number).exclude(pk=self.instance.pk).exists():
									raise ValidationError({'mobile_number':"this Mobile Number is already registered try another"})
									
		if Users_Account.objects.filter(account_number=account_number).exclude(pk=self.instance.pk).exists():
									raise ValidationError({'account_number':"this account number is already registered try another"})
							
		if Users_Account.objects.filter(card_number=card_number).exclude(pk=self.instance.pk).exists():
								raise ValidationError({'card_number':"this account number is already registered try another"})
					
		if len(mobile_number) != 10 and re.search(r"[A-Z]",mobile_number) and re.search(r"[a-z]",mobile_number) and re.search(r"[@_!#$%^&*()?/}{~:]",mobile_number):
				raise ValidationError({'mobile_number':"please enter a valid 10 digit number"})
		if not re.search(r"@",email):
			raise ValidationError({'email':'Please enter valid email id'})		
		if len(account_number) != 16 and re.search(r"[A-Z]",account_number) and re.search(r"[a-z]",account_number) and re.search(r"[@_!#$%^&*()?/}{~: ]",account_number):
				raise ValidationError({'account_number':"please enter a valid account number"})
		if len(card_number) != 16 and re.search(r"[A-Z]",card_number) and re.search(r"[a-z]",card_number) and re.search(r"[@_!#$%^&*()?/}{~:]",card_number):
				raise ValidationError({'card_number':"please enter a valid card number"})