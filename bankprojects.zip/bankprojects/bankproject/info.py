EMAIL_USE_TLS = True
EMAIL_HOST_PASSWORD = 'Siddhi@143'
EMAIL_HOST_USER= 'bankpay980@gmail.com'
EMAIL_HOST='smtp.gmail.com'
EMAIL_PORT = 587