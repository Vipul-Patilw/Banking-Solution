from django.shortcuts import render
from Bank_Admin_Portal.userscreation_view.usercreation_view import UserAccountCreate
from Bank_Admin_Portal.usersdetail_view.usersdetail import  UsersDetail

UserAccountCreate

UsersDetail

# Create your views here.
