a = ["f","ff","fff"]
import datetime
print(datetime.date.today())
# b = input(":")
# for i in a:
#     if i == b:
#         print("matched") 
#         break
# else:
#         print("not matched")