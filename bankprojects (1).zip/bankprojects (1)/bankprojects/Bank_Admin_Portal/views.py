from django.shortcuts import render,HttpResponse,redirect
from Bank_Admin_Portal.userscrud_views.usercreation_view import UserAccountCreate
from Bank_Admin_Portal.userscrud_views.userdelete import UserAccountDelete
from Bank_Admin_Portal.userscrud_views.userupdate import UserAccountUpdate
from Bank_Admin_Portal.usersdetail_view.usersdetail import  UsersDetail
from django.views.generic.edit import CreateView
from django.views.generic import TemplateView,FormView
from Bank_Admin_Portal.forms import MatchSingatureForm
from Bank_Admin_Portal.models import MatchSignature,Users_Account,SuperUserRegistration
from sentence_transformers import SentenceTransformer, util
from PIL import Image
import glob
import os
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
# from skimage.io import imread_collection
import pathlib
UsersDetail
from django.contrib.auth.views import LogoutView,PasswordChangeView,PasswordChangeForm
from django.urls import reverse_lazy
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin
# Create your views here.

UserAccountCreate
UserAccountDelete
UserAccountUpdate
 
# class SignatureMatchUserMoneyWithrawal(FormView):
#     template_name = 'signature_matching_user.html'
#     success_url = reverse_lazy('adminhome')

def signatureMatchUserMoneyWithrawal(request):
    if request.method == 'POST':

        withdraw_money = request.POST.get('withdraw_money')
        account_number = request.POST.get('account_number')
        user = Users_Account.objects.get(account_number=account_number)
        if float(withdraw_money) < user.balance:
            user.balance -= float(withdraw_money)
            user.save()
            return redirect('scaning_signature')
        else:
            ValidationError({'signature_image':"Sorry this account don't have enough balance to withdraw"}) 
            return redirect('scaning_signature')
    return render(request,'signature_matching_user.html')
      

class AdminChangePassword(AdminLoginRequiredMixin,PasswordChangeView):
	
	form_class = PasswordChangeForm
	template_name = "registration/admin_change_password.html"
	success_url = reverse_lazy('settings') 
 
 
def admin_logout(request):
  logout(request)
  return redirect('adminlogin')
  
def updateAdminProfile(request):
	if request.user.is_anonymous:
		return redirect('adminhome')
	if not request.user.is_staff:
		return redirect('adminhome')
	if request.method == 'POST':
		profile_pic = request.FILES.get('profile_pic')
		current_user = request.user
		username = current_user.username
		user = SuperUserRegistration.objects.get(username=username)
		user.profile_pic = profile_pic
		user.save()
		return redirect('admin_personal_detail')
	return render(request,"admin_personal_details.html")
 
def admin_login(request):
	try:
		if request.method =="POST":
			password= request.POST.get('password')
			username = request.POST.get('username')
			user = authenticate(username=username, password=password)

			
			if user is not None and user.is_superuser == True or user.is_staff == True:
				
				login(request, user)
				return redirect('adminhome')
			
			elif user.is_staff == False or user.is_superuser == False:
					messages.error(request, "This account don't have accessed to login as admin or staff, try using your admin or staff account!")
						
					return redirect('adminlogin')
		
			
		return render(request,'registration/superuser_login.html')
	except:
				messages.error(request, "You enter wrong username and password")
					
				return redirect('adminlogin')    

  
def scan_image_request(request):
    if request.user.is_anonymous:
    	return redirect('adminhome')
    if not request.user.is_staff:
    	return redirect('adminhome')
    if request.method == 'POST':  
        form = MatchSingatureForm(request.POST, request.FILES)  
        if form.is_valid():  
            form.save()  
  
            # Getting the current instance object to display in the template  
            object = form.instance
            img_object = object.signature_image.url
            #img_object = form.cleaned_data['signature_image']
            model = SentenceTransformer('clip-ViT-B-32')
            # images = pathlib.Path('bankproject/media/Admin_Portal/signatures/')
            # image_names = list(images.iterdir())
            local_path = str(os.path.abspath(os.getcwd())) 
            current_path = local_path + "\media\Admin_Portal\signatures\*"
            image_names = list(glob.glob(current_path))
            outside_image = local_path +str(img_object.replace("/","\\"))
            image_names.append(outside_image)
            print("Images:", outside_image)
            print("Images:", len(image_names))
            encoded_image = model.encode([Image.open(filepath) for filepath in image_names], batch_size=128, convert_to_tensor=True, show_progress_bar=True)

            processed_images = util.paraphrase_mining_embeddings(encoded_image)
            NUM_SIMILAR_IMAGES = 10
            print('Finding near duplicate images...')

            threshold = 0.99
            near_duplicates = [image for image in processed_images if image[0] < threshold]
            for score, image_id1, image_id2 in near_duplicates[0:NUM_SIMILAR_IMAGES]:
                scores = score * 100
                if scores > 85:
                    print("signature matched")
                    print("\nScore: {:.2f}%".format(score * 100))
                    print(image_names[image_id1])
                    print(image_names[image_id2])
                    # C:\Users\Ramesh Patil\Downloads\bankprojects\media\Admin_Portal\signatures\vipulSign1 - Copy.jpg
            #C:\Users\Ramesh Patil\Downloads\bankprojects\media\Admin_Portal\signatures\
                    print("loc testr")
                    sign = str(image_names[image_id1])
                    replace_sign_url = "/".join(sign.split('\\'))
                    print(replace_sign_url)
                    replace_sign_url1 = "/".join(local_path.split('\\'))
                    match_sign = replace_sign_url.replace(replace_sign_url1 +"/media/","")
                    print(f"Test:tobaby:{match_sign}")
                    user_detail = Users_Account.objects.filter(signature=match_sign).all()
                    return render(request, 'signature_matching_user.html', {'form': form, 'img_obj': img_object,'userdetail':user_detail}) 
                    
    
            else:
                    print("signature dosn't matched")

                    #raise ValidationError({'signature_image':"This Signature dosen't matched with  any account holder records"})
                    return render(request, 'scan_signature.html', {'form': form,'signature_image':"This Signature dosen't matched with  any account holder records"})
             
    else:  
        form = MatchSingatureForm()
  
    return render(request, 'scan_signature.html', {'form': form})  



#class MatchSignatureView(CreateView):
#    template_name = "scan_signature.html"
#    form_class = MatchSingatureForm
#    success_url="signature_matched_user"
#    def form_valid(self,form):
#        signature_image = form.cleaned_data['signature_image']
#        return super(MatchSignatureView, self).form_valid(form)
#        
        # print('Loading CLIP Model...')
     #   model = SentenceTransformer('clip-ViT-B-32')

#        image_names = list(glob.glob('..//media//Admin_Portal//signatures//*.jpg'))
#        outside_image = '..//media//Admin_Portal//match_signatures//'+str(signature_image)
#        image_names.append(outside_image)

#        # print("Images:", len(image_names))
#        encoded_image = model.encode([Image.open(filepath) for filepath in image_names], batch_size=128, convert_to_tensor=True, show_progress_bar=True)

#        processed_images = util.paraphrase_mining_embeddings(encoded_image)
#        NUM_SIMILAR_IMAGES = 10
#        print('Finding near duplicate images...')

#        threshold = 0.99
#        near_duplicates = [image for image in processed_images if image[0] < threshold]
#        for score, image_id1, image_id2 in near_duplicates[0:NUM_SIMILAR_IMAGES]:
#            scores = score * 100
#            if scores > 85:
#                print("signature matched")
#                print("\nScore: {:.2f}%".format(score * 100))
#                print(image_names[image_id1])
#                print(image_names[image_id2])

#            else:
#                raise ValidationError({'signature_image':"This Signature dosen't matched with  any account holder records"})



# class SignatureMatchingUser(TemplateView):
#     template_name = 'signature_matching_user.html'
    
#     def get_context_data(self, *args,**kwargs):
#         context = super(SignatureMatchingUser, self).get_context_data(*args,**kwargs)
#         sign_img =  f"Admin_Portal/match_signatures/{kwargs['signature_image']}"
#         sign = MatchSignature.objects.get(signature_image=sign_img)
#         context = sign 
#         return {'signature_image':context}