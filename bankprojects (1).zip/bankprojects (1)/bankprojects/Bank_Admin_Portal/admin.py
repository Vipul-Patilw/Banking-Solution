from django.contrib import admin

# Register your models here.
from Bank_Admin_Portal.models import Users_Account,MatchSignature,SuperUserRegistration,Staff,Admin
# Register your models here.
admin.site.register(Users_Account)
admin.site.register(MatchSignature)
admin.site.register(SuperUserRegistration)
admin.site.register(Staff)
admin.site.register(Admin)