from Bank_Admin_Portal.models import Users_Account
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin
from django.views.generic import ListView
#import cv2
#import  numpy as np
#import matplotlib.pyplot as plt 

class UsersDetail(AdminLoginRequiredMixin,ListView,):
		model = Users_Account
		template_name = 'usersdetail.html'
		context_object_name = 'users_list'
		paginate_by = 10
		
		
		# sign_img = plt.imshow(mask)
		# extra_context = {'singnature_img':sign_img}
		