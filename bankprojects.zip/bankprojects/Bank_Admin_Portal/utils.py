#import cv2
#import numpy as n
def get_scaned_signatured(image):
    pass
    #   filtered_signatured = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
#    # signature = cv2.imread(image,cv2.COLOR_BGR2RGB)
#    # lower = np.array([90, 38, 0])
#    # upper = np.array([145, 255, 255])
#    # filtered_signatured = cv2.inRange(signature, lower, upper)
#    return filtered_si
