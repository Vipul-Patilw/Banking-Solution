from Bank_Admin_Portal.models import Staff,Admin
from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth.models import User
from django.views.generic import  TemplateView,ListView
from django.urls import  reverse_lazy,reverse
from django.shortcuts import render,redirect
from Bank_Admin_Portal.ajax_request import is_ajax
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin

class StaffView(AdminLoginRequiredMixin,ListView):
	model = Staff
	template_name = 'staff_request.html'
	context_object_name = 'staff_data'
	paginate_by = 3
	def get_template_names(self):
		template_name = 'staff_request.html'
		if is_ajax(self.request):
			template_name = 'staff_request_ajax.html'
		return template_name

class AdminView(AdminLoginRequiredMixin,ListView):
	model = Admin
	template_name = 'admin_request.html'
	context_object_name = 'admin_data'
	paginate_by = 3
	def get_template_names(self):
		template_name = 'admin_request.html'
		if is_ajax(self.request):
			template_name = 'admin_request_ajax.html'
		return template_name
	

class StaffUserRequests(AdminLoginRequiredMixin,TemplateView):
		template_name = "staff_request.html"
		success_url = reverse_lazy("staff_request")
		def dispatch(self,*args,**kwargs):
				user = User.objects.get(username=kwargs['username'])
				if kwargs['assecedfor'] == "staff" and kwargs['response'] == "accept":
					user.is_active = True
					user.is_staff = True
					user.save()
					staff = Staff.objects.get(username=kwargs['username'])
					staff.delete()
					return redirect('staff_request')
				elif kwargs['assecedfor']=="staff" and kwargs['response'] == "delete":
					staff = Staff.objects.get(username=kwargs['username'])
					staff.delete()
					user.delete()
					return redirect('staff_request')
				return super(StaffUserRequests,self).dispatch(*args,**kwargs)
						
class AdminUserRequests(AdminLoginRequiredMixin,TemplateView):
			template_name = 'admin_request.html'
			success_url = reverse_lazy('admin_request')
			def dispatch(self,*args,**kwargs):
				user = User.objects.get(username=kwargs['username'])
				if kwargs['assecedfor'] == "admin" and kwargs['response'] == "accept":
						user.is_active = True
						user.is_superuser = True
						user.is_staff = True
						user.save()
						admin = Admin.objects.get(username=kwargs['username'])
						admin.delete()
						return redirect('admin_request')
						
				elif kwargs['assecedfor'] =="admin" and kwargs['response'] == "delete":
						admin = Admin.objects.get(username=kwargs['username'])
						admin.delete()
						user.delete()
						return redirect('admin_request')
				return super(AdminUserRequests,self).dispatch(*args,**kwargs)
		
