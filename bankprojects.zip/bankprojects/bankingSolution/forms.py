from bankingSolution.uservarificationform.userverification import UserVerificationForm
from Bank_Admin_Portal.models import Users_Account
from django import forms


UserVerificationForm

