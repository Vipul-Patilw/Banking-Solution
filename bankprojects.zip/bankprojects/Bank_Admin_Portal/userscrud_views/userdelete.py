from Bank_Admin_Portal.models import Users_Account
from django.urls import reverse_lazy
from django.views.generic.edit import DeleteView
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin
class UserAccountDelete(AdminLoginRequiredMixin,DeleteView):
		model = Users_Account
		template_name = 'delete_holder_account.html'
		success_url = reverse_lazy('adminhome')