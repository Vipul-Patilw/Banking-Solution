from django.test import TestCase

# Create your tests here.
import os
a = str(os.path.abspath(os.getcwd())) 
b =  a +      "\media\Admin_Portal\match_signatures\\"

print(b)