from django import forms
from Bank_Admin_Portal.models import  RechargePlan
class RechargePlanForm(forms.ModelForm):
	class Meta:
		model = RechargePlan
		fields = '__all__'
		exclude = ('add_update_date',)
		widgets= {'recharge_operator':forms.Select(attrs={'class':'form-select'}),
		'recharge_plan':forms.Textarea(attrs={'class':'form-control'}),
		'recharge_amount':forms.NumberInput(attrs={'class':'form-control'}),	'recharge_validity_days':forms.NumberInput(attrs={'class':'form-control'})}
		