from django.contrib import admin
from django.urls import path,include
from Bank_Admin_Portal import  views
from Bank_Admin_Portal.registration_view import superusercreate
from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView
from Bank_Admin_Portal.recharge_plan.recharge_plan_view import RechargePlanView,RechagePlanDelete,RechargePlanList,RechargePlanUpdate
from Bank_Admin_Portal.registration_view.user_request import AdminUserRequests,StaffUserRequests,StaffView,AdminView

urlpatterns = [
path('recharge_plan_list',RechargePlanList.as_view(),name='recharge_plan_list'),
path('recharge_plan/<pk>',RechargePlanUpdate.as_view()),
path('recharge_plan/delete/<pk>',RechagePlanDelete.as_view()),
path('recharge_plan_form',RechargePlanView.as_view(),name='recharge_plan_form'),
	path('superuser/login/', views.admin_login,name="adminlogin"),
	path('superuser/logout',views.admin_logout,name='adminlogout'),
		path('staff_request',StaffView.as_view(),name='staff_request'),
		path('admin_request',AdminView.as_view(),name='admin_request'),
		path('admin_request/<username>/<assecedfor>/<response>',AdminUserRequests.as_view()),
		path('staff_request/<username>/<assecedfor>/<response>',StaffUserRequests.as_view()),
	  path('superuser/password_change',views.AdminChangePassword.as_view(),name="adminpassword"),
	path('superuser/personal_details',views.updateAdminProfile,name='admin_personal_detail'),
#	path('superuser/login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('superuser/create',superusercreate.SuperUserCreate.as_view(),name='admin'), 
     path('smu',TemplateView.as_view( template_name="signature_matching_user.html"),name='smu'),
  
     path('about',TemplateView.as_view( template_name="admin_about.html"),name='admin_about'),
 path('privacy-policy',TemplateView.as_view( template_name="privacy-policy.html"),name='privacy-policy'),
    path('setting',TemplateView.as_view( template_name="settings.html"),name='settings'),
    path('user/account-create',views.UserAccountCreate.as_view(),name='useraccount'),
    path('user/account-update/<pk>',views.UserAccountUpdate.as_view(),name='useraccountupdate'),
     path('user/account-delete/<pk>',views.UserAccountDelete.as_view(),name='useraccountdelete'),
    path('scaning_signature',views.scan_image_request,name='scaning_signature'),
   path('signature_matched_user',views.signatureMatchUserMoneyWithrawal,name='signature_matched_user'),
    # path('signature_matched_user',views.SignatureMatchingUser.as_view(),name='signature_matched_user'),
    path('',views.UsersDetail.as_view(),name='adminhome'),

   ]


   